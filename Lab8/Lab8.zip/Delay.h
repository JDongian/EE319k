
#define timeScale 100000

void delay(unsigned int);
